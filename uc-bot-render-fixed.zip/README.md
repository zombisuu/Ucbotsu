# UC Bot (Render + FastAPI + aiogram)

## ⚙️ Qanday ishlaydi?
Bot FastAPI yordamida 10000-portda web server ochadi va Telegram uchun webhook sozlanadi. 
Shu orqali UptimeRobot har 5 daqiqada ping yuboradi va bot 24/7 ishlaydi.

## 📦 Qanday joylash kerak?
1. GitHub repo oching va shu fayllarni joylang.
2. Render.com’da ✅:
   - New Web Service → Import from GitHub → Sizning repo.
   - Runtime: Python 3.x
   - Build: `pip install -r requirements.txt`
   - Start: `python bot.py`
   - Port: `10000`
3. Deploy qiling va `https://botuc.onrender.com/` manzilda `{ "status": "UC bot 24/7 ishlayapti 🔥" }` qaytishini tekshiring.

## ⏱ UptimeRobot sozlash
- `HTTP(s)` ping → `https://botuc.onrender.com` → interval 5 min → Create Monitor

Endi bot 24/7 onlayn bo‘ladi!
