import logging
from aiogram import Bot, Dispatcher, types
from aiogram.utils.executor import start_webhook
from fastapi import FastAPI
import uvicorn
import asyncio
import os

API_TOKEN = "7597893955:AAGUNmm_7mm80TBiJJd0NXRixktQ-Xs44uY"

WEBHOOK_HOST = 'https://botuc.onrender.com'
WEBHOOK_PATH = ''
WEBHOOK_URL = f"{WEBHOOK_HOST}{WEBHOOK_PATH}"

WEBAPP_HOST = "0.0.0.0"
WEBAPP_PORT = int(os.environ.get("PORT", 10000))  # Auto detect port from Render

bot = Bot(token=API_TOKEN)
dp = Dispatcher(bot)
app = FastAPI()

@app.get("/")
def read_root():
    return {"status": "UC bot 24/7 ishlayapti 🔥"}

@dp.message_handler(commands=['start'])
async def send_welcome(message: types.Message):
    await message.answer("👋 Salom! UC bot 24/7 ishlayapti!")

async def on_startup(dp):
    await bot.set_webhook(WEBHOOK_URL)

async def on_shutdown(dp):
    await bot.delete_webhook()

def start():
    loop = asyncio.get_event_loop()
    from threading import Thread
    def start_bot():
        start_webhook(
            dispatcher=dp,
            webhook_path=WEBHOOK_PATH,
            on_startup=on_startup,
            on_shutdown=on_shutdown,
            skip_updates=True,
            host=WEBAPP_HOST,
            port=WEBAPP_PORT,
        )
    Thread(target=start_bot).start()
    uvicorn.run(app, host=WEBAPP_HOST, port=WEBAPP_PORT)

if __name__ == '__main__':
    start()
